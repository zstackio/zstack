ansible-modules-core
====================

This repo contains Ansible's most popular modules that are shipped with Ansible.

New module submissions for modules that do not yet exist should be submitted to ansible-modules-extras, rather than this repo.

Take care to submit tickets to the appropriate repo where modules are contained.  The docs.ansible.com website indicates this at the bottom of each module documentation page.

License
=======

As with Ansible, modules distributed with Ansible are GPLv3 licensed.  User generated modules not part of this project can be of any license.
